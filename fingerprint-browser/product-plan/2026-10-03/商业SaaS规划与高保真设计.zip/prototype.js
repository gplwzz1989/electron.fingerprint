'use strict'

const paths = {
  grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  browser: '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M3 9h18M7 6.5h.01M10 6.5h.01"/>',
  globe: '<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18M5 7h14M5 17h14"/>',
  users: '<circle cx="9" cy="8" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3M16 5a3 3 0 0 1 0 6M21 21v-3a6 6 0 0 0-4-5"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  wallet: '<rect x="3" y="5" width="18" height="15" rx="3"/><path d="M3 9h18M15 13h6v4h-6zM7 5V3h11v2"/>',
  settings: '<path d="m9 3-1 3-3 1-2 3 2 2-1 3 3 2 1 3h4l1-3 3-1 2-3-2-2 1-3-3-2-1-3H9Z"/><circle cx="10" cy="12" r="3"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
  bell: '<path d="M6 8a6 6 0 0 1 12 0v7l2 3H4l2-3V8ZM9 21h6"/>',
  help: '<circle cx="12" cy="12" r="9"/><path d="M9 9a3 3 0 1 1 4 3c-1 .4-1 1-1 2M12 17h.01"/>',
  play: '<path d="m8 4 12 8-12 8V4Z"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="1.5"/>',
  shield: '<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6l8-3Z"/><path d="m8 12 3 3 5-6"/>',
  alert: '<path d="m12 3 10 18H2L12 3ZM12 9v5M12 17h.01"/>',
  check: '<path d="m5 12 4 4L19 6"/>',
  checkCircle: '<circle cx="12" cy="12" r="9"/><path d="m7 12 3 3 7-7"/>',
  sync: '<path d="M20 7v5h-5M4 17v-5h5M5 7a8 8 0 0 1 13-1l2 3M4 15l2 3a8 8 0 0 0 13-1"/>',
  cloud: '<path d="M6 18a5 5 0 0 1-1-10 7 7 0 0 1 13-1 5.5 5.5 0 0 1 0 11H6Z"/>',
  download: '<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>',
  upload: '<path d="M12 16V4m-5 5 5-5 5 5M4 16v5h16v-5"/>',
  folder: '<path d="M3 7V4h7l3 3h8v13H3V7Z"/>',
  arrow: '<path d="M5 12h14m-5-5 5 5-5 5"/>',
  left: '<path d="m14 5-7 7 7 7"/>',
  close: '<path d="m6 6 12 12M6 18 18 6"/>',
  lock: '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/>',
  monitor: '<rect x="3" y="3" width="18" height="13" rx="2"/><path d="M8 21h8M12 16v5"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 6 9 7 9-7"/>',
  fingerprint: '<path d="M4 11a8 8 0 0 1 16 0M7 13v-2a5 5 0 0 1 10 0v4c0 3-1 5-2 7M10 16v-5a2 2 0 0 1 4 0v5c0 2-.6 4-1.5 5M4 14v2c0 2 .5 4 1.5 5M7 17c0 2 .5 3 1 4M20 14v3"/>',
  more: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
  chart: '<path d="M4 3v17h17M8 15l4-5 4 3 5-8"/>',
  file: '<path d="M5 3h9l5 5v13H5V3ZM14 3v5h5M8 13h8M8 17h6"/>'
}
const icon = name => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.browser}</svg>`
const escapeHTML = value => String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]))
const btn = (label, action, style = '', extra = '', symbol = '') => `<button class="button ${style}" data-action="${action}" ${extra}>${symbol ? icon(symbol) : ''}${label}</button>`
const badge = (text, color = '') => `<span class="status ${color}"><i class="dot"></i>${text}</span>`
const navItems = [['overview', '工作台', 'grid'], ['environments', '浏览器环境', 'browser'], ['proxies', '代理资源', 'globe'], ['members', '团队成员', 'users'], ['audit', '操作记录', 'clock'], ['billing', '订阅与用量', 'wallet'], ['settings', '设置', 'settings']]
const environments = [
  { id: 'QJ-1001', name: '美国旗舰店 · 主账号', group: '电商运营', site: '店铺后台', letter: '美', country: '美国 · 纽约', code: 'US', ip: '198.51.100.24', owner: '林沐', state: '运行中', sync: '已同步', time: '今天 09:42', color: 'orange' },
  { id: 'QJ-1002', name: '英国品牌店 · 运营', group: '电商运营', site: '品牌独立站', letter: '英', country: '英国 · 伦敦', code: 'GB', ip: '203.0.113.56', owner: '陈悦', state: '已关闭', sync: '已同步', time: '今天 09:36', color: '' },
  { id: 'QJ-1003', name: '内容营销 · 法国', group: '内容营销', site: '内容工作台', letter: '法', country: '法国 · 巴黎', code: 'FR', ip: '192.0.2.18', owner: '王宁', state: '代理异常', sync: '仅本地', time: '今天 09:21', color: 'purple' },
  { id: 'QJ-1004', name: '美国店 · 备用', group: '电商运营', site: '店铺后台', letter: '备', country: '美国 · 洛杉矶', code: 'US', ip: '198.51.100.77', owner: '林沐', state: '已关闭', sync: '已同步', time: '昨天 18:06', color: 'orange' },
  { id: 'QJ-1005', name: '德国业务 · 客服', group: '客户支持', site: '客服工作台', letter: '德', country: '德国 · 柏林', code: 'DE', ip: '203.0.113.80', owner: '周禾', state: '运行中', sync: '已同步', time: '今天 09:18', color: '' },
  { id: 'QJ-1006', name: '日本品牌 · 内容', group: '内容营销', site: '品牌内容库', letter: '日', country: '日本 · 东京', code: 'JP', ip: '192.0.2.46', owner: '王宁', state: '已关闭', sync: '同步失败', time: '昨天 17:52', color: 'purple' },
  { id: 'QJ-1007', name: '加拿大业务 · 运营', group: '电商运营', site: '店铺后台', letter: '加', country: '加拿大 · 多伦多', code: 'CA', ip: '198.51.100.92', owner: '陈悦', state: '已关闭', sync: '已同步', time: '昨天 16:35', color: '' },
  { id: 'QJ-1008', name: '澳大利亚 · 客服', group: '客户支持', site: '客服工作台', letter: '澳', country: '澳大利亚 · 悉尼', code: 'AU', ip: '203.0.113.112', owner: '周禾', state: '已关闭', sync: '仅本地', time: '昨天 15:20', color: '' }
]
const members = [
  ['林沐', 'linmu@example.com', '所有者', '全部环境', '今天 09:42', '有效'],
  ['陈悦', 'chenyue@example.com', '管理员', '电商运营 · 4 个环境', '今天 09:36', '有效'],
  ['王宁', 'wangning@example.com', '操作者', '内容营销 · 2 个环境', '今天 09:21', '有效'],
  ['周禾', 'zhouhe@example.com', '操作者', '客户支持 · 2 个环境', '今天 09:18', '有效'],
  ['赵晨', 'zhaochen@example.com', '只读成员', '电商运营 · 4 个环境', '等待接受邀请', '待接受']
]
let route = 'overview'
let filter = 'all'
let searchTerm = ''
let groupFilter = '全部分组'
let wizardStep = 1
let proxyChecked = false
let currentEnvironment = environments[0]
let toastTimer
let lastFocus
let draft = { name: '美国旗舰店 · 运营', group: '电商运营', storage: 'local' }
let selected = new Set()

function heading(title, subtitle, actions = '', eyebrow = '') {
  return `<div class="page-heading"><div>${eyebrow ? `<div class="eyebrow">${eyebrow}</div>` : ''}<h1>${title}</h1><p>${subtitle}</p></div><div class="actions">${actions}</div></div>`
}
function metrics() {
  const running = environments.filter(e => e.state === '运行中').length
  const issues = environments.filter(e => e.state === '代理异常' || e.sync === '同步失败').length
  return `<div class="metrics"><div class="card metric"><span class="metric-icon">${icon('browser')}</span><div><small>环境总数</small><b>${environments.length}</b><p>3 个业务分组</p></div></div><div class="card metric"><span class="metric-icon green">${icon('play')}</span><div><small>正在运行</small><b>${running}<span> 个环境</span></b><p>本机独立会话</p></div></div><div class="card metric"><span class="metric-icon orange">${icon('alert')}</span><div><small>需要处理</small><b>${issues}<span> 项</span></b><p>代理与同步异常</p></div></div><div class="card metric"><span class="metric-icon purple">${icon('chart')}</span><div><small>环境配额</small><b>${environments.length}<span> / 300</span></b><div class="progress"><i style="width:${Math.max(8, environments.length / 3)}%"></i></div></div></div></div>`
}
function overview() {
  return `${heading('早上好，林沐', '今天的业务环境已准备就绪。先处理异常，再开始团队的日常工作。', btn('新建环境', 'create', 'primary', '', 'plus'), '你的团队工作空间')}
  <section class="welcome"><div><h2>把每个业务，放进独立的环境</h2><p>从创建到交接，让登录状态、访问权限和工作记录都有清晰归属。</p><div class="welcome-steps"><span>${icon('checkCircle')}创建工作空间</span><span>${icon('checkCircle')}建立首个环境</span><span>${icon('users')}邀请同事开始协作</span></div></div><div class="actions">${btn('查看新手引导', 'onboarding', 'soft')}</div><div class="welcome-art">${icon('fingerprint')}</div></section>
  ${metrics()}<div class="overview-grid"><div><section class="card"><div class="card-head"><h2>最近使用的环境</h2><a class="button text small" href="#environments">查看全部 ${icon('arrow')}</a></div>${environments.slice(0, 5).map(e => `<div class="recent-row"><span class="env-logo ${e.color}">${e.letter}</span><div class="grow"><button class="env-title" data-action="detail" data-id="${e.id}">${e.name}</button><p>${e.group} <span class="footer-divider">·</span> ${e.country}</p></div>${badge(e.state, e.state === '运行中' ? 'green' : e.state === '代理异常' ? 'orange' : '')}${btn(e.state === '运行中' ? '进入' : e.state === '代理异常' ? '诊断' : '打开', e.state === '代理异常' ? 'diagnostic' : 'launch', e.state === '代理异常' ? 'small' : 'small soft', `data-id="${e.id}"`)}</div>`).join('')}</section><div class="system-card"><div class="actions">${icon('shield')}<b style="font-size:12px">数据保存位置由你决定</b><span class="tiny-tag" style="margin-left:auto">本地优先</span></div><p>仅本地环境不会上传登录数据。开启云同步前，请确认存储范围和获授权成员；不同系统的会话交接需通过兼容性检查。</p></div></div><div><section class="card"><div class="card-head"><h2>需要你的关注</h2><span class="status orange">2 项</span></div><div class="issue"><span class="issue-icon">${icon('globe')}</span><div><b>法国环境的代理连接失败</b><p>最后检查于 09:21，启动已阻止。</p>${btn('检查代理连接', 'diagnostic', 'text small', 'data-id="QJ-1003"')}</div></div><div class="issue"><span class="issue-icon">${icon('sync')}</span><div><b>日本环境未完成云同步</b><p>本机数据已保存，团队版本未更新。</p>${btn('查看同步状态', 'detail', 'text small', 'data-id="QJ-1006"')}</div></div></section><div class="mini-heading"><h3>团队最近动态</h3><a href="#audit" class="muted" style="font-size:10px">全部记录 →</a></div><section class="card card-body"><div class="activity"><i class="timeline-dot"></i><div>林沐打开了美国旗舰店<p>今天 09:42 · 本机客户端</p></div></div><div class="activity"><i class="timeline-dot"></i><div>陈悦完成英国环境同步<p>今天 09:36 · 上海办公电脑</p></div></div><div class="activity"><i class="timeline-dot"></i><div>赵晨收到工作空间邀请<p>昨天 18:40 · 等待接受</p></div></div></section></div></div>`
}
function filteredEnvironments() {
  return environments.filter(e => (filter === 'all' || (filter === 'running' ? e.state === '运行中' : e.state === '代理异常' || e.sync === '同步失败')) && (groupFilter === '全部分组' || e.group === groupFilter) && `${e.name} ${e.owner} ${e.id}`.toLowerCase().includes(searchTerm.toLowerCase()))
}
function environmentRows() {
  const list = filteredEnvironments()
  if (!list.length) return `<tr><td colspan="8"><div class="empty">${icon('search')}<h2>没有找到匹配的环境</h2><p>试试其他关键词，或清除分组和状态筛选。</p>${btn('清除筛选', 'reset-filters')}</div></td></tr>`
  return list.map(e => `<tr><td><input type="checkbox" data-select="${e.id}" aria-label="选择${escapeHTML(e.name)}" ${selected.has(e.id) ? 'checked' : ''}></td><td><div class="env-name"><span class="env-logo ${e.color}">${e.letter}</span><div><button class="env-title" data-action="detail" data-id="${e.id}">${escapeHTML(e.name)}</button><div class="env-meta"><span>${e.id}</span><span class="chip">${e.group}</span></div></div></div></td><td><span class="country">${e.code}</span>${e.country}<span class="cell-sub mono">${e.ip}</span></td><td><span class="person"><span class="avatar ${e.owner === '王宁' ? 'purple' : ''}">${e.owner[0]}</span>${e.owner}</span></td><td><span class="sync ${e.sync === '同步失败' ? 'warning' : e.sync === '仅本地' ? 'local' : ''}">${icon(e.sync === '仅本地' ? 'monitor' : 'sync')}${e.sync}</span></td><td>${badge(e.state, e.state === '运行中' ? 'green' : e.state === '代理异常' ? 'orange' : '')}</td><td><span style="font-size:10px;color:#7d8a9c">${e.time}</span></td><td><div class="row-actions">${btn(e.state === '运行中' ? '进入' : e.state === '代理异常' ? '诊断' : '打开', e.state === '代理异常' ? 'diagnostic' : 'launch', e.state === '代理异常' ? 'small' : 'small soft', `data-id="${e.id}"`)}<button class="icon-button" aria-label="查看${escapeHTML(e.name)}的详情" data-action="detail" data-id="${e.id}">${icon('more')}</button></div></td></tr>`).join('')
}
function environmentPage(empty = false) {
  return `${heading('浏览器环境', '管理业务的独立会话，保持登录状态和团队访问有序。', btn('导入环境', 'import', '', '', 'upload') + btn('新建环境', 'create', 'primary', '', 'plus'))}${metrics()}
  <section class="card"><div class="tabs"><button class="tab ${filter === 'all' ? 'active' : ''}" data-filter="all">全部环境<span>${environments.length}</span></button><button class="tab ${filter === 'running' ? 'active' : ''}" data-filter="running">正在运行<span>${environments.filter(e => e.state === '运行中').length}</span></button><button class="tab ${filter === 'issues' ? 'active' : ''}" data-filter="issues">需要处理<span>2</span></button></div>
  ${empty ? `<div class="empty">${icon('browser')}<h2>创建你的第一个浏览器环境</h2><p>为一个业务建立独立会话。名称、分组和代理可在创建时设置。</p>${btn('创建第一个环境', 'create', 'primary', '', 'plus')}</div>` : `<div class="table-toolbar"><label class="search-field">${icon('search')}<input id="env-search" aria-label="搜索环境名称、编号或负责人" placeholder="搜索环境名称、编号或负责人" value="${escapeHTML(searchTerm)}"></label><select class="filter" id="group-filter" aria-label="筛选业务分组">${['全部分组', '电商运营', '内容营销', '客户支持'].map(x => `<option ${x === groupFilter ? 'selected' : ''}>${x}</option>`).join('')}</select>${btn('重置', 'reset-filters', 'text small')}<span class="toolbar-note">最近使用优先 · IP 为示例地址</span></div><div class="table-wrap"><table class="env-table"><thead><tr><th style="width:38px"><input type="checkbox" id="select-all" aria-label="选择当前筛选下的全部环境"></th><th>环境名称</th><th>代理与地区</th><th>负责人</th><th>同步状态</th><th>运行状态</th><th>最近使用</th><th>操作</th></tr></thead><tbody id="env-rows">${environmentRows()}</tbody></table></div><div class="bulkbar" id="bulkbar" ${selected.size ? '' : 'hidden'}><span id="selected-count">已选择 ${selected.size} 个环境</span>${btn('批量打开', 'bulk-launch', 'small')}${btn('批量关闭', 'bulk-close', 'small')}${btn('取消选择', 'clear-selection', 'text small')}</div><div class="table-footer"><span id="row-count">显示 ${filteredEnvironments().length} 个环境 · 共 ${environments.length} 个</span><div class="pagination"><span>20 条 / 页</span><span class="page-box">‹</span><span class="page-box current">1</span><span class="page-box">›</span></div></div>`}</section><p class="below-note">${icon('lock')}环境间隔离数据；同一环境内的网页标签共享登录会话。修改模板不会改变已有环境的指纹快照。</p>`
}
function createPage() {
  const title = wizardStep === 1 ? '为新业务建立一个独立空间' : wizardStep === 2 ? '连接代理，确认访问地区' : '检查指纹配置并创建' 
  const subtitle = wizardStep === 1 ? '给环境一个便于识别的名称，再选择业务分组与保存方式。' : wizardStep === 2 ? '连接检查通过后再继续。使用代理时，连接失败会阻止启动。' : '推荐模板按宿主与运行时能力校验，创建后保存为稳定快照。'
  let fields = ''
  if (wizardStep === 1) fields = `<label class="field"><span>环境名称<span class="required">*</span></span><input name="name" required maxlength="80" value="${escapeHTML(draft.name)}" placeholder="例如：美国旗舰店 · 运营"><small>用业务和用途命名，便于团队找到正确环境。</small></label><div class="form-row"><label class="field"><span>业务分组</span><select name="group">${['电商运营', '内容营销', '客户支持'].map(g => `<option ${g === draft.group ? 'selected' : ''}>${g}</option>`).join('')}</select></label><label class="field"><span>负责人</span><select><option>林沐（我）</option><option>陈悦</option><option>王宁</option></select></label></div><label class="field"><span>启动网址</span><input type="url" value="https://example.com" name="url"><small>示例网址，可在创建后修改。</small></label><div class="form-divider"></div><label class="field"><span>环境数据保存方式</span></label><div class="radio-cards"><label class="radio-card"><input name="storage" type="radio" value="local" ${draft.storage === 'local' ? 'checked' : ''}><span>仅本地<small>数据保存在这台设备上，不上传登录会话。</small></span></label><label class="radio-card"><input name="storage" type="radio" value="cloud" ${draft.storage === 'cloud' ? 'checked' : ''}><span>启用云同步<small>供授权成员交接；跨系统恢复需要兼容性检查。</small></span></label></div><div class="notice">${icon('shield')}新环境默认仅负责人和管理员可以访问，可在创建后调整授权。</div>`
  if (wizardStep === 2) fields = `<label class="field"><span>代理来源</span><select><option>从代理资源选择</option></select></label><label class="field"><span>代理资源<span class="required">*</span></span><div class="inline-check"><select name="proxy"><option>美国静态代理 03 · 纽约</option></select>${btn('检查连接', 'check-proxy', '', '', 'sync')}</div><small>演示地址 198.51.100.24 · HTTP 代理 · 凭据已隐藏</small></label><div id="proxy-feedback" class="notice ${proxyChecked ? 'success' : ''}">${icon(proxyChecked ? 'checkCircle' : 'globe')}${proxyChecked ? '演示检查通过 · 美国纽约 · 126 ms；这不是实际网络检测。' : '尚未检查连接。请先检查代理，再继续创建。'}</div><div class="form-divider"></div><div class="form-row"><label class="field"><span>时区</span><select><option>跟随代理地区 · 美国东部</option></select><small>具体时区：America/New_York</small></label><label class="field"><span>语言</span><select><option>英语（美国）</option></select><small>网页语言与请求语言保持一致。</small></label></div><div class="notice warning">${icon('alert')}代理变更可能影响访问地区。已创建环境不会自动更换指纹快照。</div>`
  if (wizardStep === 3) fields = `<div class="template-option"><div><b>本机推荐模板 · 版本 1</b><p>Windows 桌面 · 真实能力校验后才能用于实际运行</p></div>${badge('推荐', 'blue')}</div><div class="definition-grid"><div><span>浏览器内核</span><b>当前兼容内核（设计占位）</b></div><div><span>操作系统模板</span><b>Windows 桌面</b></div><div><span>语言与时区</span><b>英语（美国） · 纽约</b></div><div><span>屏幕与缩放</span><b>1920 × 1080 · 1.0</b></div><div><span>会话</span><b>新建独立环境目录</b></div><div><span>指纹种子</span><b>每个环境生成并保持稳定</b></div></div><div class="form-divider"></div><div class="notice success">${icon('checkCircle')}演示配置检查完成：语言、时区、代理地区没有发现冲突。</div><div class="notice warning" style="margin-top:12px">${icon('alert')}模板通过校验不代表已通过所有网站检测。WebGL、字体与跨系统一致性需实机验证。</div><details class="advanced"><summary>查看高级指纹参数</summary><div class="definition-grid"><div><span>Canvas / Audio</span><b>稳定的环境种子</b></div><div><span>WebRTC</span><b>限制非代理 UDP</b></div><div><span>UA 与 Client Hints</span><b>跟随已验证运行时</b></div><div><span>GPU 与字体</span><b>本机兼容模板</b></div></div></details>`
  return `${heading('新建浏览器环境', '三步完成创建。先明确业务，再确认网络与指纹配置。', btn('取消创建', 'cancel-create'))}<div class="steps">${['基本信息', '代理与地区', '指纹配置'].map((label, i) => `${i ? '<div class="step-line"></div>' : ''}<div class="step ${wizardStep === i + 1 ? 'active' : wizardStep > i + 1 ? 'done' : ''}"><i>${wizardStep > i + 1 ? icon('check') : i + 1}</i>${label}</div>`).join('')}</div><div class="form-layout"><form class="card" id="wizard-form"><div class="form-content"><div class="form-intro"><h2>${title}</h2><p>${subtitle}</p></div>${fields}</div><div class="form-footer">${wizardStep > 1 ? btn('上一步', 'wizard-back', '', 'type="button"', 'left') : '<small>必填项已标注 *</small>'}<button class="button primary" type="submit">${wizardStep === 3 ? '创建环境' : '保存并继续'}${icon('arrow')}</button></div></form><aside class="card summary-card"><h3>创建预览</h3><div class="summary-item"><span>环境名称</span><b id="preview-name">${escapeHTML(draft.name)}</b></div><div class="summary-item"><span>所属分组</span><b>${draft.group}</b></div><div class="summary-item"><span>保存方式</span><b>${draft.storage === 'cloud' ? '云同步（用户启用）' : '仅本地'}</b></div><div class="summary-item"><span>代理地区</span><b>美国 · 纽约</b></div><div class="summary-feature"><span>${icon('browser')}</span><div><b>独立登录会话</b><p>Cookie、缓存与业务数据归属于当前环境。</p></div></div><div class="summary-feature"><span>${icon('fingerprint')}</span><div><b>稳定的指纹快照</b><p>重新打开继续使用原快照，不因模板更新而变化。</p></div></div><div class="summary-feature"><span>${icon('users')}</span><div><b>按需授权成员</b><p>仅获授权成员可访问，敏感导出权限单独管理。</p></div></div><p class="summary-note">这是交互设计演示。不会创建真实浏览器目录、连接代理或上传数据。</p></aside></div>`
}
function proxiesPage() {
  const items = [['美国静态代理 03', 'HTTP', '美国 · 纽约', '198.51.100.24:8080', '126 ms', '2', '可用'], ['英国业务代理 01', 'SOCKS5', '英国 · 伦敦', '203.0.113.56:1080', '158 ms', '1', '可用'], ['法国内容代理 02', 'HTTP', '法国 · 巴黎', '192.0.2.18:8080', '—', '1', '连接失败'], ['德国客服代理 01', 'HTTP', '德国 · 柏林', '203.0.113.80:8080', '142 ms', '1', '可用'], ['日本内容代理 01', 'SOCKS5', '日本 · 东京', '192.0.2.46:1080', '86 ms', '1', '可用']]
  return `${heading('代理资源', '统一管理网络出口，按环境绑定。代理凭据不会显示给未授权成员。', btn('批量导入', 'import-proxies', '', '', 'upload') + btn('添加代理', 'add-proxy', 'primary', '', 'plus'))}<div class="notice warning" style="margin-bottom:24px">${icon('alert')}1 个代理连接异常，相关环境的启动已阻止。最后检查于今天 09:21。${btn('查看诊断', 'diagnostic', 'text small', 'data-id="QJ-1003"')}</div><section class="card"><div class="card-head"><h2>代理列表 <span class="tiny-tag">5 个资源</span></h2>${btn('检查全部连接', 'check-all-proxies', 'small', '', 'sync')}</div><div class="table-wrap"><table><thead><tr><th>代理名称 / 类型</th><th>出口地区</th><th>地址</th><th>响应延迟</th><th>已绑定环境</th><th>检测结果</th><th>操作</th></tr></thead><tbody>${items.map((p, i) => `<tr><td><div class="env-name"><span class="env-logo">${icon('globe')}</span><div><b style="font-size:12px;font-weight:500">${p[0]}</b><span class="cell-sub">${p[1]} · 密码已隐藏</span></div></div></td><td>${p[2]}</td><td class="mono">${p[3]}</td><td>${p[4]}</td><td>${p[5]} 个</td><td>${badge(p[6], i === 2 ? 'orange' : 'green')}</td><td>${btn(i === 2 ? '诊断' : '检查', i === 2 ? 'diagnostic' : 'check-single-proxy', 'small', 'data-id="QJ-1003"')}</td></tr>`).join('')}</tbody></table></div><div class="table-footer">连接结果为设计演示，所有 IP 使用文档保留地址。<span>检测结果不等于长期可用性</span></div></section><div class="settings-grid stack-gap"><section class="card card-body"><h3>批量导入前先预览</h3><p class="summary-note">支持协议、地址与认证字段的格式校验，重复项和错误行逐项标记。确认之前不写入代理资源。</p>${btn('查看导入流程', 'import-proxies', 'text small')}</section><section class="card card-body"><h3>连接失败的默认行为</h3><p class="summary-note">不静默切换到本机网络。更换代理后需重新检查，再打开相关环境。</p>${badge('阻止直连', 'blue')}</section></div>`
}
function membersPage() {
  return `${heading('团队成员', '把正确的环境交给正确的人。成员角色与业务范围分别管理。', btn('邀请成员', 'invite', 'primary', '', 'plus'))}<section class="card"><div class="invite-banner"><span class="metric-icon">${icon('users')}</span><div><b style="font-size:13px">5 / 10 个成员席位</b><p>待接受的邀请占用席位。离职成员可停用并撤销后续访问。</p></div><a class="button small" href="#billing">查看席位用量</a></div><div class="table-wrap"><table><thead><tr><th>成员</th><th>角色</th><th>可访问范围</th><th>最近活跃</th><th>状态</th><th>操作</th></tr></thead><tbody>${members.map((m, i) => `<tr><td><div class="person"><span class="avatar ${i === 2 ? 'purple' : 'blue'}">${escapeHTML(m[0][0])}</span><div><b style="font-size:12px;font-weight:500">${escapeHTML(m[0])}</b><span class="cell-sub">${escapeHTML(m[1])}</span></div></div></td><td>${m[2]}</td><td>${m[3]}</td><td style="color:var(--muted);font-size:11px">${m[4]}</td><td>${badge(m[5], m[5] === '有效' ? 'green' : 'orange')}</td><td>${i === 0 ? '<span class="tiny-tag">当前账号</span>' : btn(m[5] === '有效' ? '管理授权' : '查看邀请', 'permissions', 'small', `data-index="${i}"`)}</td></tr>`).join('')}</tbody></table></div></section><div class="settings-grid stack-gap"><section class="card card-body"><h3>角色控制操作，授权控制范围</h3><p class="summary-note">管理员可以管理成员和环境；操作者只能运行获授权环境；只读成员不能启动环境或读取凭据。计费与所有权由所有者管理。</p></section><section class="card card-body"><h3>敏感导出单独授权</h3><p class="summary-note">默认不授予 Cookie 与代理凭据导出权限。权限变更会写入操作记录；已复制的本地数据无法保证远程抹除。</p></section></div>`
}
function auditPage() {
  const events = [['09:42:18', '林沐', '打开环境', '美国旗舰店 · 主账号', '本机客户端', '成功'], ['09:36:05', '陈悦', '提交同步版本', '英国品牌店 · 运营', '上海办公电脑', '成功'], ['09:21:44', '王宁', '检查代理', '法国内容代理 02', '本机客户端', '连接失败'], ['09:18:12', '周禾', '打开环境', '德国业务 · 客服', '客服工作电脑', '成功'], ['昨天 18:40', '林沐', '邀请成员', '赵晨 · 只读成员', '本机客户端', '邀请已发送'], ['昨天 17:52', '王宁', '提交同步版本', '日本品牌 · 内容', '本机客户端', '上传失败'], ['昨天 16:35', '陈悦', '关闭环境', '加拿大业务 · 运营', '上海办公电脑', '成功']]
  return `${heading('操作记录', '查看成员、设备与环境的操作结果，追踪异常和权限变更。', btn('导出脱敏记录', 'export-audit', '', '', 'download'))}<section class="card"><div class="table-toolbar"><span class="tiny-tag">今天及昨天</span><span class="tiny-tag">全部成员</span><span class="tiny-tag">全部操作类型</span>${btn('筛选记录', 'audit-filters', 'small')}<span class="toolbar-note">时间按当前工作空间时区显示</span></div><div class="table-wrap"><table><thead><tr><th>时间</th><th>操作成员</th><th>操作类型</th><th>操作对象</th><th>设备</th><th>结果</th></tr></thead><tbody>${events.map(e => `<tr><td class="mono">${e[0]}</td><td><span class="person"><span class="avatar">${e[1][0]}</span>${e[1]}</span></td><td>${e[2]}</td><td>${e[3]}</td><td style="color:var(--muted);font-size:11px">${e[4]}</td><td><span class="audit-result ${e[5].includes('失败') ? 'warning' : ''}">${e[5]}</span></td></tr>`).join('')}</tbody></table></div><div class="table-footer">演示 7 条操作记录<span>保留范围与期限以正式套餐说明为准</span></div></section><p class="below-note">${icon('shield')}记录不包含代理密码、Cookie、网页正文和完整浏览历史。导出需要专门权限。</p>`
}
function billingPage() {
  const plans = [['个人版', '独立业务，轻松开始', '99', ['50 个环境', '1 个成员席位', '本地环境与稳定快照', '基础诊断与安全升级'], '选择个人版'], ['团队版', '多人成员，有序交接', '299', ['300 个环境', '10 个成员席位', '分组授权与操作记录', '10 GB 云同步空间'], '当前演示套餐'], ['成长版', '更大规模的运营团队', '899', ['1,000 个环境', '30 个成员席位', '30 GB 云同步空间', '接口权限与优先支持'], '查看升级方案']]
  return `${heading('订阅与用量', '清楚了解每一项配额，再选择适合团队的方案。', btn('查看账单', 'invoices'))}<div class="notice warning" style="margin-bottom:22px">${icon('alert')}以下价格、配额、期限均为设计占位，尚未成为正式报价。代理流量不包含在这些示例套餐中。</div><section class="card billing-current"><div><div class="eyebrow">当前演示订阅</div><h2>团队版 ${badge('有效', 'green')}</h2><p>按月订阅 · 示例到期日期 2026-11-03<br>降级与到期不会删除本地环境。</p></div><div class="billing-usage"><div><small>环境</small><b>${environments.length}<span> / 300</span></b></div><div><small>成员席位</small><b>${members.length}<span> / 10</span></b></div><div><small>同步空间</small><b>1.2<span> / 10 GB</span></b></div></div></section><div class="plan-grid">${plans.map((p, i) => `<section class="card plan ${i === 1 ? 'featured' : ''}">${i === 1 ? '<span class="plan-label">适合团队</span>' : ''}<h2>${p[0]}</h2><p>${p[1]}</p><div class="price">¥${p[2]}<span> / 工作空间 / 月</span></div><p>仅为布局演示，正式定价待验证</p><ul>${p[3].map(x => `<li>${icon('check')}${x}</li>`).join('')}</ul>${i === 1 ? '<button class="button soft" disabled>当前演示套餐</button>' : btn(p[4], 'plan-preview', i === 2 ? 'primary' : '', `data-plan="${p[0]}"`)}</section>`).join('')}</div><div class="settings-grid stack-gap"><section class="card card-body"><h3>配额的计算方式</h3><p class="summary-note">待接受邀请占用成员席位；环境删除后的回收站计数规则需要在正式套餐说明中确认。云同步空间只计算已启用同步的环境。</p></section><section class="card card-body"><h3>到期、超限和降级</h3><p class="summary-note">保留本地数据和导出能力；已打开窗口可以安全关闭。超限时限制新增，降级前先预览受影响项目。</p></section></div>`
}
function settingsPage() {
  return `${heading('客户端设置', '管理这台设备的存储、更新与诊断，不影响团队其他成员的本机设置。')}<div class="settings-grid"><div><section class="card"><div class="card-head"><h2>本机与数据</h2><span class="tiny-tag">演示设备</span></div><div class="setting-row"><div><b>设备名称</b><p>运营工作电脑 · Windows x64（演示）</p></div>${btn('编辑', 'device-name', 'small')}</div><div class="setting-row"><div><b>环境数据保存位置</b><p>系统应用数据目录 · 不依赖项目源码路径</p></div>${btn('迁移预览', 'migration', 'small')}</div><div class="setting-row"><div><b>关闭环境前创建恢复点</b><p>完成一致性检查后再保存，磁盘不足时给出提醒。</p></div><button class="switch on" data-action="toggle" role="switch" aria-checked="true" aria-label="关闭环境前创建恢复点"><i></i></button></div><div class="setting-row"><div><b>首次运行环境时检查代理</b><p>连接失败会阻止启动，不静默切换本机网络。</p></div><span class="status blue">默认开启</span></div></section><section class="card stack-gap"><div class="card-head"><h2>更新与诊断</h2></div><div class="setting-row"><div><b>稳定版更新通道</b><p>运行中的环境关闭后再安装；更新前保留迁移备份。</p></div>${btn('检查更新', 'updates', 'small')}</div><div class="setting-row"><div><b>导出诊断包</b><p>导出前预览内容，不包含 Cookie 或代理密码。</p></div>${btn('预览诊断', 'diagnostic-export', 'small')}</div><div class="setting-row"><div><b>减少界面动效</b><p>自动跟随系统偏好。</p></div><span class="tiny-tag">跟随系统</span></div></section></div><aside><section class="card card-body"><div class="metric-icon">${icon('shield')}</div><h2 style="margin-top:18px">能力以实际内核为准</h2><p class="summary-note">定制运行时、浏览器内核与模板支持需要分别显示。当前原型没有连接运行时，不能验证本机指纹能力。</p><div class="summary-item"><span>应用版本</span><b>商业版设计稿</b></div><div class="summary-item"><span>实际运行时</span><b>未连接</b></div><div class="summary-item"><span>指纹能力检查</span><b>待实机验证</b></div>${btn('查看版本规划', 'version-plan', 'text small')}</section><section class="card card-body stack-gap"><h3>常用快捷键</h3><div class="summary-item"><span>全局搜索</span><b>Ctrl / ⌘ + K</b></div><div class="summary-item"><span>创建环境</span><b>Ctrl / ⌘ + N</b></div><div class="summary-item"><span>浏览器地址栏</span><b>Ctrl / ⌘ + L</b></div></section></aside></div><div class="release-grid">${[['Windows x64', '干净系统安装、签名与升级迁移', 'monitor'], ['macOS · Intel', '原生 x64 运行时、签名与公证', 'monitor'], ['macOS · Apple Silicon', '原生 arm64 实机运行、签名与公证', 'monitor']].map(p => `<section class="card release-card">${icon(p[2])}<h3>${p[0]}</h3><p>${p[1]}</p>${badge('商业交付待实施', 'blue')}</section>`).join('')}</div>`
}
function browserPage() {
  const e = currentEnvironment
  return `${heading('环境浏览器', '同一业务环境内可打开多个网页标签；不同环境的会话互相隔离。', btn('返回环境列表', 'return-env', '', '', 'left'))}<div class="browser-surface"><div class="browser-envbar"><div>${icon('browser')}<strong>${escapeHTML(e.name)}</strong><span class="chip">${e.id}</span></div><div>${badge('独立会话', 'green')}<span>${e.country} · ${e.ip}</span></div></div><div class="browser-tabs"><button class="browser-tab active" data-action="browser-tab" data-tab="业务概览">${icon('grid')}业务概览 ${icon('close')}</button><button class="browser-tab" data-action="browser-tab" data-tab="订单管理">${icon('file')}订单管理 ${icon('close')}</button><button class="browser-tab" data-action="browser-tab" data-tab="帮助中心">${icon('help')}帮助中心 ${icon('close')}</button><button class="icon-button" aria-label="新建网页标签" data-action="new-browser-tab">${icon('plus')}</button></div><form class="browser-address" id="address-form"><button class="icon-button" aria-label="浏览器后退" type="button" data-action="browser-back">${icon('left')}</button><button class="icon-button" aria-label="刷新演示内容" type="button" data-action="browser-refresh">${icon('sync')}</button><label class="address-input">${icon('lock')}<input id="browser-address" aria-label="浏览器地址" value="https://example.com/workspace" spellcheck="false"><span class="tiny-tag">演示页面</span></label><button class="icon-button" aria-label="下载管理" type="button" data-action="downloads">${icon('download')}</button><button class="icon-button" aria-label="站点权限" type="button" data-action="site-permissions">${icon('shield')}</button></form><div class="browser-content"><div class="website-title"><div><div class="eyebrow">示例业务后台</div><h2 id="website-title">业务概览</h2><p>这是产品设计中的示例页面，不会访问真实站点。</p></div><span class="tiny-tag">今天 · 2026 年 10 月 3 日</span></div><div class="browser-widgets"><div class="browser-widget"><small>今日订单</small><b>128</b><p>较昨日增加 12.3% · 示例</p></div><div class="browser-widget"><small>待处理订单</small><b>24</b><p>团队处理中 · 示例</p></div><div class="browser-widget"><small>客户咨询</small><b>16</b><p>最近 24 小时 · 示例</p></div></div><section class="card card-body stack-gap"><h3>最近七天的订单趋势</h3><div class="order-bars" aria-label="示例订单趋势图">${[35, 48, 42, 57, 65, 58, 82, 72, 91, 79, 94, 100].map(h => `<i style="height:${h}%"></i>`).join('')}</div><div class="table-footer" style="padding:10px 0 0;border:0">9 月 27 日 <span>10 月 3 日</span></div></section></div><div class="browser-summary"><span>${icon('shield')} 本环境标签共享 Cookie 与登录状态</span><span>代理检查：演示通过 · 同步：${e.sync} · 站点权限：按需询问</span></div></div><p class="below-note">${icon('fingerprint')}目标交互设计：一个环境一个浏览器窗口，窗口内多网页标签；现有 Demo 的独立标签数据将分别保留为环境。</p>`
}
function detailDrawer(e, diagnostic = false) {
  const fail = e.sync === '同步失败'
  return `<div class="backdrop" data-dismiss="drawer"><section class="drawer" role="dialog" aria-modal="true" aria-labelledby="drawer-title"><div class="drawer-head"><span class="env-logo ${e.color}">${e.letter}</span><div><h2 id="drawer-title">${diagnostic ? '环境启动诊断' : escapeHTML(e.name)}</h2><p>${e.id} · ${e.group}</p></div><button class="icon-button" aria-label="关闭详情" data-action="close-overlay">${icon('close')}</button></div>${diagnostic ? '' : '<div class="tabs"><span class="tab active">概览</span><span class="tab">指纹快照</span><span class="tab">活动</span></div>'}<div class="drawer-body">${diagnostic ? `<div class="notice error">${icon('alert')}代理连接失败，环境未启动。没有使用本机网络。</div><h3>检查结果</h3><div class="diagnostic-step">${icon('checkCircle')}<div>本地环境目录可读<p>原指纹快照和登录数据已保留。</p></div></div><div class="diagnostic-step">${icon('checkCircle')}<div>当前设备未发现占用冲突<p>可在代理恢复后重试打开。</p></div></div><div class="diagnostic-step failed">${icon('alert')}<div>代理连接未完成<p>示例代理 192.0.2.18:8080 连接超时。请检查服务状态、地址和认证信息。</p></div></div><div class="diagnostic-step failed">${icon('lock')}<div>启动已阻止<p>避免网络出口意外变为本机地址。</p></div></div><h3>建议下一步</h3><div class="info-box">1. 检查代理是否有效、账号是否到期。<br>2. 在代理资源中更新地址或认证信息。<br>3. 重新检查连接，再打开这个环境。</div><h3>诊断信息</h3><div class="detail-kv"><span>检查时间</span><b>今天 09:21:44</b><span>请求编号</span><b class="mono">demo-check-1003</b><span>数据处理</span><b>没有删除或重置任何数据</b></div>` : `<div class="detail-banner">${badge(e.state, e.state === '运行中' ? 'green' : e.state === '代理异常' ? 'orange' : '')}<span class="muted" style="font-size:10px">最近使用：${e.time}</span></div><h3>基本信息</h3><div class="detail-kv"><span>负责人</span><b>${e.owner}</b><span>代理地区</span><b>${e.country}</b><span>出口 IP</span><b class="mono">${e.ip}（示例）</b><span>保存方式</span><b>${e.sync === '仅本地' ? '仅本地' : '已启用云同步（演示）'}</b><span>来源模板</span><b>桌面推荐模板 · 修订 1</b><span>指纹快照</span><b>创建后保持稳定</b></div><h3>同步与交接</h3><div class="notice ${fail ? 'warning' : 'success'}">${icon(fail ? 'alert' : 'checkCircle')}${fail ? '本机已保存，云上传失败。团队版本未更新；可重试，不能覆盖冲突版本。' : e.sync === '仅本地' ? '本地环境不上传登录数据。' : '演示：本地版本 v12 与团队版本 v12 一致。'}</div><div class="info-box">${fail ? '本地版本 v13 · 远端版本 v12<br>错误原因：网络连接中断（演示）' : '当前占用：' + (e.state === '运行中' ? '林沐 · 本机客户端' : '未占用') + '<br>会话交接前需要关闭窗口并完成一致性检查。'}</div>${fail ? btn('重试同步', 'retry-sync', 'soft', `data-id="${e.id}"`) : ''}<h3>访问权限</h3><div class="detail-kv"><span>授权范围</span><b>${e.group} 分组成员</b><span>敏感导出</span><b>默认关闭，需专门授权</b></div><h3>最近活动</h3><div class="activity"><i class="timeline-dot"></i><div>环境打开后保持原指纹快照<p>${e.time} · ${e.owner}</p></div></div><div class="activity"><i class="timeline-dot"></i><div>创建环境并绑定业务分组<p>2026-10-01 14:20 · 林沐</p></div></div><div class="notice">${icon('shield')}此抽屉内容为设计示例，并非当前项目实际运行结果。</div>`}</div><div class="drawer-footer">${diagnostic ? btn('前往代理资源', 'open-proxies') + btn('重新检查', 'retry-diagnostic', 'primary') : e.state === '运行中' ? btn('关闭环境', 'close-env', '', `data-id="${e.id}"`, 'stop') + btn('进入环境', 'launch', 'primary', `data-id="${e.id}"`, 'play') : btn('关闭详情', 'close-overlay') + btn(e.state === '代理异常' ? '查看诊断' : '打开环境', e.state === '代理异常' ? 'diagnostic' : 'launch', 'primary', `data-id="${e.id}"`, 'play')}</div></section></div>`
}
function toast(message) {
  clearTimeout(toastTimer)
  const node = document.getElementById('toast')
  node.textContent = message
  node.classList.add('show')
  toastTimer = setTimeout(() => node.classList.remove('show'), 4200)
}
function showOverlay(html) {
  lastFocus = document.activeElement
  document.getElementById('overlay-root').innerHTML = html
  document.body.style.overflow = 'hidden'
  const focus = document.querySelector('#overlay-root input, #overlay-root button, #overlay-root select')
  if (focus) focus.focus()
}
function closeOverlay() {
  document.getElementById('overlay-root').innerHTML = ''
  document.body.style.overflow = ''
  if (lastFocus && lastFocus.isConnected) lastFocus.focus()
}
function dialog(title, body, footer = btn('知道了', 'close-overlay', 'primary')) {
  showOverlay(`<div class="dialog-backdrop" data-dismiss="dialog"><section class="dialog" role="dialog" aria-modal="true" aria-labelledby="dialog-title"><div class="card-head"><h2 id="dialog-title">${title}</h2><button class="icon-button" aria-label="关闭对话框" data-action="close-overlay">${icon('close')}</button></div><div class="card-body">${body}</div><div class="form-footer"><span></span><div class="actions">${footer}</div></div></section></div>`)
}
function onboarding() {
  showOverlay(`<div class="dialog-backdrop"><section class="dialog onboarding" role="dialog" aria-modal="true" aria-labelledby="onboarding-title"><div class="onboarding-grid"><div class="onboarding-story"><span class="brand-mark">${icon('fingerprint')}</span><h2>一个工作空间，<br>有序开展业务。</h2><p>从本地开始，按需邀请同事和开启云同步。</p><ul><li>每个业务保留独立会话</li><li>团队成员按授权访问</li><li>异常可诊断，数据可恢复</li></ul></div><form class="onboarding-form" id="onboarding-form"><h2 id="onboarding-title">设置你的工作空间</h2><p>这是首次使用流程演示，不会创建真实账号。</p><label class="field"><span>工作空间名称<span class="required">*</span></span><input required name="workspace" value="远航出海团队" maxlength="80"></label><label class="field"><span>主要业务</span><select><option>跨境电商与品牌运营</option><option>营销与内容协作</option><option>客户支持</option></select></label><div class="radio-cards"><label class="radio-card"><input type="radio" name="mode" checked><span>先使用本地环境<small>默认不上传登录数据，稍后按需开启同步。</small></span></label></div><button class="button primary" type="submit">开始创建首个环境 ${icon('arrow')}</button><button class="button text" type="button" data-action="close-overlay" style="margin-top:10px">稍后设置</button></form></div></section></div>`)
}
function render() {
  closeOverlay()
  route = location.hash.slice(1) || 'overview'
  const parent = ['create', 'detail', 'diagnostic', 'empty', 'browser'].includes(route) ? 'environments' : route === 'onboarding' ? 'overview' : route
  document.getElementById('navigation').innerHTML = navItems.map(([id, title, symbol]) => `<a class="nav-link ${id === parent ? 'active' : ''}" href="#${id}" ${id === parent ? 'aria-current="page"' : ''}>${icon(symbol)}<span>${title}</span>${id === 'proxies' ? '<span class="nav-count">1</span>' : ''}</a>`).join('')
  document.getElementById('breadcrumb').textContent = (navItems.find(n => n[0] === parent) || navItems[0])[1]
  document.getElementById('sidebar-quota').textContent = `${environments.length} / 300`
  const views = { overview, environments: environmentPage, create: createPage, proxies: proxiesPage, members: membersPage, audit: auditPage, billing: billingPage, settings: settingsPage, browser: browserPage, detail: environmentPage, diagnostic: environmentPage, empty: () => environmentPage(true), onboarding: overview }
  document.getElementById('main').innerHTML = (views[route] || overview)()
  window.scrollTo(0, 0)
  if (route === 'detail') showOverlay(detailDrawer(currentEnvironment))
  if (route === 'diagnostic') showOverlay(detailDrawer(environments[2], true))
  if (route === 'onboarding') onboarding()
}
function navigate(next) {
  if (location.hash === `#${next}`) render()
  else location.hash = next
}
function refreshRows() {
  document.getElementById('env-rows').innerHTML = environmentRows()
  document.getElementById('row-count').textContent = `显示 ${filteredEnvironments().length} 个环境 · 共 ${environments.length} 个`
  document.getElementById('selected-count').textContent = `已选择 ${selected.size} 个环境`
  document.getElementById('bulkbar').hidden = selected.size === 0
  document.getElementById('select-all').checked = filteredEnvironments().length > 0 && filteredEnvironments().every(e => selected.has(e.id))
}

document.addEventListener('click', event => {
  const target = event.target.closest('[data-action], [data-route], [data-filter], [data-dismiss]')
  if (!target) return
  if (target.dataset.dismiss && event.target === target) return closeOverlay()
  if (target.dataset.route) return navigate(target.dataset.route)
  if (target.dataset.filter) { filter = target.dataset.filter; return render() }
  const action = target.dataset.action
  const e = environments.find(item => item.id === target.dataset.id) || currentEnvironment
  if (target.closest('form') && target.tagName === 'BUTTON' && !target.hasAttribute('type')) event.preventDefault()
  switch (action) {
    case 'create': wizardStep = 1; proxyChecked = false; draft = { name: '美国旗舰店 · 运营', group: '电商运营', storage: 'local' }; navigate('create'); break
    case 'return-env': case 'cancel-create': closeOverlay(); navigate('environments'); break
    case 'detail': currentEnvironment = e; showOverlay(detailDrawer(e)); break
    case 'diagnostic': currentEnvironment = e; showOverlay(detailDrawer(e, true)); break
    case 'close-overlay': closeOverlay(); break
    case 'onboarding': onboarding(); break
    case 'launch': currentEnvironment = e; e.state = '运行中'; navigate('browser'); toast('已模拟打开环境；没有启动真实浏览器会话。'); break
    case 'close-env': e.state = '已关闭'; closeOverlay(); navigate('environments'); toast('已模拟关闭环境，登录数据保留。'); break
    case 'reset-filters': filter = 'all'; searchTerm = ''; groupFilter = '全部分组'; selected.clear(); render(); break
    case 'clear-selection': selected.clear(); refreshRows(); break
    case 'bulk-launch': {
      let blocked = 0
      selected.forEach(id => { const item = environments.find(x => x.id === id); if (item.state === '代理异常') blocked++; else item.state = '运行中' })
      const amount = selected.size - blocked
      selected.clear(); render(); toast(`已模拟打开 ${amount} 个环境${blocked ? `；${blocked} 个代理异常环境已阻止` : ''}。`); break
    }
    case 'bulk-close': selected.forEach(id => { const item = environments.find(x => x.id === id); if (item.state === '运行中') item.state = '已关闭' }); selected.clear(); render(); toast('批量关闭演示完成，原数据保留。'); break
    case 'wizard-back': wizardStep--; render(); break
    case 'check-proxy': proxyChecked = true; document.getElementById('proxy-feedback').className = 'notice success'; document.getElementById('proxy-feedback').innerHTML = icon('checkCircle') + '演示检查通过 · 美国纽约 · 126 ms；这不是实际网络检测。'; break
    case 'retry-diagnostic': toast('模拟重新检查：代理仍未连接。请先更新代理资源。'); break
    case 'open-proxies': navigate('proxies'); break
    case 'retry-sync': e.sync = '已同步'; showOverlay(detailDrawer(e)); toast('同步重试演示完成，本地副本保留；没有实际上传。'); break
    case 'check-single-proxy': case 'check-all-proxies': toast('演示检查完成：4 个可用、1 个连接失败；未执行真实网络检测。'); break
    case 'invite': dialog('邀请团队成员', `<form id="invite-form"><label class="field"><span>成员姓名</span><input name="name" required maxlength="40" placeholder="例如：赵晨"></label><label class="field"><span>邮箱<span class="required">*</span></span><input name="email" required type="email" placeholder="member@example.com"></label><div class="form-row"><label class="field"><span>成员角色</span><select name="role"><option>操作者</option><option>管理员</option><option>只读成员</option></select></label><label class="field"><span>授权分组</span><select name="group"><option>电商运营</option><option>内容营销</option><option>客户支持</option></select></label></div><div class="notice">${icon('lock')}默认关闭敏感数据导出权限。这是邀请演示，不发送邮件。</div></form>`, btn('取消', 'close-overlay') + '<button class="button primary" type="submit" form="invite-form">创建邀请演示</button>'); break
    case 'permissions': {
      const member = members[Number(target.dataset.index)]
      dialog(`${escapeHTML(member[0])}的访问权限`, `<p>角色：${member[2]}<br>范围：${member[3]}</p><div class="thin-rule"></div><div class="notice">${icon('shield')}可以查看获授权环境的元数据。${member[2] === '只读成员' ? '只读成员不能启动环境。' : '运行环境按角色允许。'} Cookie 与代理凭据导出默认关闭。</div><p style="margin-top:20px">完整的撤权、过期邀请和权限编辑列入团队 Beta 开发；本原型仅演示授权摘要。</p>`); break
    }
    case 'plan-preview': dialog(`确认${target.dataset.plan}的配额口径`, '<p>此处用于评审升级流程。价格、含税方式、扣款周期、环境/席位/空间上限需在正式购买前再次确认。</p><div class="notice warning" style="margin-top:18px">本原型没有接入支付，不会生成订单或扣款。</div>'); break
    case 'invoices': dialog('账单与付款记录', '<p>正式版会显示订单、付款状态、周期、金额、币种与发票入口；支付结果由服务端验证回调确认。</p><div class="info-box">当前没有真实账单。套餐页面的金额均为设计占位。</div>'); break
    case 'search': dialog('搜索环境与功能', `<label class="field"><span>环境关键词</span><input id="global-search-input" placeholder="名称、编号或负责人"></label><p>输入关键词后，前往环境列表查看结果。</p>`, btn('取消', 'close-overlay') + btn('搜索环境', 'perform-search', 'primary', '', 'search')); break
    case 'perform-search': searchTerm = document.getElementById('global-search-input').value; filter = 'all'; groupFilter = '全部分组'; closeOverlay(); navigate('environments'); break
    case 'notifications': filter = 'issues'; navigate('environments'); break
    case 'toggle': { const on = target.getAttribute('aria-checked') !== 'true'; target.classList.toggle('on', on); target.setAttribute('aria-checked', String(on)); toast('已切换演示设置，不影响真实客户端。'); break }
    case 'browser-tab': document.querySelectorAll('.browser-tab').forEach(tab => tab.classList.toggle('active', tab === target)); document.getElementById('website-title').textContent = target.dataset.tab; break
    case 'new-browser-tab': { const tab = document.createElement('button'); tab.className = 'browser-tab'; tab.dataset.action = 'browser-tab'; tab.dataset.tab = '新标签'; tab.innerHTML = `${icon('browser')}新标签 ${icon('close')}`; target.before(tab); toast('已添加环境内网页标签演示，共享本环境会话。'); break }
    case 'browser-refresh': case 'browser-back': toast('浏览器导航为设计演示，不执行真实页面请求。'); break
    case 'downloads': dialog('当前环境的下载', '<p>暂无下载任务。正式版下载需归属于当前环境，并提供保存位置、取消、失败重试和来源信息。</p>'); break
    case 'site-permissions': dialog('站点权限 · 示例页面', '<p>摄像头、麦克风、定位、通知均按来源与环境询问。不会因为使用指纹浏览器默认允许权限。</p><div class="info-box">本原型没有请求设备权限。</div>'); break
    case 'export-audit': dialog('导出操作记录', '<p>导出字段：时间、成员、设备、操作类型、目标与结果。默认脱敏，不含 Cookie、代理凭据和网页正文。</p><div class="notice" style="margin-top:15px">当前只展示导出预览，没有生成真实审计文件。</div>'); break
    case 'audit-filters': dialog('筛选操作记录', '<p>正式版支持日期范围、成员、操作类型和结果组合筛选。本稿使用固定示例记录，供字段与状态评审。</p>'); break
    case 'import': case 'import-proxies': dialog(action === 'import' ? '导入环境 · 预览流程' : '批量导入代理 · 预览流程', '<p>选择文件 → 校验格式与重复项 → 逐项预览 → 确认导入。失败行保留错误原因，不覆盖已有环境。</p><div class="notice warning" style="margin-top:18px">本稿没有读取用户文件或处理真实凭据。文件导入列入后续开发。</div>'); break
    case 'add-proxy': dialog('添加代理', '<label class="field"><span>代理名称</span><input placeholder="例如：美国静态代理 04"></label><div class="form-row"><label class="field"><span>类型</span><select><option>HTTP</option><option>SOCKS5</option></select></label><label class="field"><span>服务器地址</span><input placeholder="示例地址，不输入真实凭据"></label></div><p>正式版包含认证信息与保存前连接检查。本稿只演示字段布局。</p>'); break
    case 'diagnostic-export': dialog('诊断包内容预览', '<p>应用版本、实际内核版本、设备架构、能力检测结果、脱敏的错误记录。</p><div class="notice success" style="margin-top:18px">不包含登录数据、代理密码、网页正文或系统密钥。</div>'); break
    case 'migration': dialog('数据迁移预览', '<p>正式版先检测原目录与空间，再创建备份。迁移成功并校验后才切换路径，失败继续使用原目录。</p><div class="info-box">当前原型不访问或移动你的真实数据。</div>'); break
    case 'updates': dialog('检查更新', '<p>原型未连接更新服务。正式版需检查产物签名、版本兼容和环境占用，在安全关闭窗口后安装。</p>'); break
    case 'version-plan': dialog('三平台运行时规划', '<p>Windows x64、macOS Intel x64、macOS Apple Silicon arm64 分别构建与实机验证。网页平台字符串不能证明 CPU 架构支持。</p><div class="notice warning" style="margin-top:18px">目前没有从原型连接真实运行时，页面不能证明上述商业交付已经完成。</div>'); break
    case 'device-name': dialog('本机设备名称', '<label class="field"><span>设备名称</span><input value="运营工作电脑" maxlength="80"></label><p>这是字段设计预览，不会修改系统设备名称。</p>'); break
    case 'workspace': dialog('切换工作空间', '<p>当前演示工作空间：远航出海团队。</p><div class="info-box">正式版按组织隔离环境、成员、代理与账单，不跨空间自动共享数据。</div>'); break
    case 'help': dialog('帮助与支持', '<p>评审入口：完整开发计划、设计交付规范、关键页面 PNG 和官方竞品资料均保存在本原型所在目录。</p><div class="info-box">本次没有连接客服或发送任何外部消息。</div>'); break
  }
})

document.addEventListener('input', event => {
  if (event.target.id === 'env-search') { searchTerm = event.target.value; refreshRows() }
  if (event.target.name === 'name' && event.target.closest('#wizard-form')) document.getElementById('preview-name').textContent = event.target.value
})
document.addEventListener('change', event => {
  const target = event.target
  if (target.id === 'group-filter') { groupFilter = target.value; refreshRows() }
  if (target.dataset.select) { target.checked ? selected.add(target.dataset.select) : selected.delete(target.dataset.select); refreshRows() }
  if (target.id === 'select-all') { filteredEnvironments().forEach(e => target.checked ? selected.add(e.id) : selected.delete(e.id)); refreshRows() }
})
document.addEventListener('submit', event => {
  event.preventDefault()
  if (event.target.id === 'wizard-form') {
    if (wizardStep === 1) { const data = new FormData(event.target); draft = { name: String(data.get('name')).trim(), group: data.get('group'), storage: data.get('storage') }; if (!draft.name) { toast('请输入环境名称。'); return } }
    if (wizardStep === 2 && !proxyChecked) { toast('请先检查代理连接，再继续创建。'); document.querySelector('[data-action="check-proxy"]').focus(); return }
    if (wizardStep < 3) { wizardStep++; render(); return }
    const item = { ...environments[0], id: `QJ-${1001 + environments.length}`, name: draft.name, group: draft.group, state: '已关闭', sync: draft.storage === 'local' ? '仅本地' : '已同步', time: '刚刚创建' }
    environments.push(item); currentEnvironment = item
    dialog('环境已创建 · 演示', `<div class="success-view"><span class="success-icon">${icon('check')}</span><h2>${escapeHTML(draft.name)}</h2><p>已加入演示列表。没有创建真实目录、会话或云端数据。<br>现在可以继续预览环境浏览器。</p></div>`, btn('返回环境列表', 'return-env') + btn('打开环境', 'launch', 'primary', `data-id="${item.id}"`, 'play'))
  }
  if (event.target.id === 'invite-form') { const data = new FormData(event.target); members.push([String(data.get('name')).trim(), String(data.get('email')).trim(), data.get('role'), data.get('group'), '等待接受邀请', '待接受']); closeOverlay(); render(); toast('已加入邀请演示列表，没有发送邮件。') }
  if (event.target.id === 'onboarding-form') { closeOverlay(); wizardStep = 1; navigate('create'); toast('已完成工作空间设置演示，继续创建首个环境。') }
  if (event.target.id === 'address-form') toast('地址已输入；原型不会访问真实网站。')
})
document.addEventListener('keydown', event => {
  if (event.key === 'Escape') closeOverlay()
  const dialogNode = document.querySelector('#overlay-root [role="dialog"]')
  if (dialogNode && event.key === 'Tab') {
    const focusable = [...dialogNode.querySelectorAll('button:not(:disabled),input,select,textarea,a[href],summary')]
    const first = focusable[0], last = focusable[focusable.length - 1]
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus() }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus() }
  }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); document.querySelector('[data-action="search"]').click() }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'n' && !dialogNode) { event.preventDefault(); document.querySelector('[data-action="create"]')?.click() }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'l' && route === 'browser') { event.preventDefault(); document.getElementById('browser-address').select() }
})
window.addEventListener('hashchange', render)
document.getElementById('support-icon').innerHTML = icon('help')
document.getElementById('search-icon').innerHTML = icon('search')
document.getElementById('notification-icon').innerHTML = icon('bell')
render()
